
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }

    public String say(String message) {
       return  "Hello World";
    }
}
