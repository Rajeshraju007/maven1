public class HelloWorldTest {
    public static void main(String[] args) {
        HelloWorld helloWorld = new HelloWorld();
        System.out.println(helloWorld.say("Hi"));
    }

}
